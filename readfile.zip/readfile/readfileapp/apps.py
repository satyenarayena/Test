from django.apps import AppConfig


class ReadfileappConfig(AppConfig):
    name = 'readfileapp'
