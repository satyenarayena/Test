from .views import *
from django.urls import path

urlpatterns = [
    path('',readfile),

    # path('', include("dailysystemapp.urls")),
]