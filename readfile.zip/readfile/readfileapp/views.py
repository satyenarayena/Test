from django.shortcuts import render
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from django.http import HttpResponse
import os,json
from pathlib import Path
import configparser,yaml

# Create your views here.



def readfile(request):
    if request.method == 'POST' and request.FILES['myfile']:
        # try:
        myfile = request.FILES['myfile']
        fs = FileSystemStorage()
        filename_list = myfile.name.split(".")
        file_path = os.path.join(settings.MEDIA_ROOT, myfile.name)
        files = Path(file_path)
        if files.is_file():
            os.remove(file_path)
        filename = fs.save(myfile.name, myfile)
        if filename_list[-1] == "yml":
            with open(file_path, 'r') as stream:
                try:
                    result=yaml.safe_load(stream)
                    return HttpResponse(json.dumps(result))
                except yaml.YAMLError as exc:
                    print(exc)
        else:
            with open(file_path) as f:
                lines = f.read().splitlines()
                reult = [i.replace("[", "").replace("]", "") for i in lines if "[" in i]
                print(reult)
                configParser = configparser.RawConfigParser()
                configFilePath = file_path
                configParser.read(configFilePath)
                details_dicts = {j: dict(configParser.items(j, "keys")) for j in reult}
                return HttpResponse(json.dumps(details_dicts))
    return render(request, 'simpleupload.html')
